using System;
using System.Runtime.CompilerServices;

namespace Library.DualGlobe.ERP.Models
{
	public class ExpenseCategory
	{
		public string Description
		{
			get;
			set;
		}

		public int Id
		{
			get;
			set;
		}

		public ExpenseCategory()
		{
		}
	}
}